
import { GoogleGenAI, Type } from "@google/genai";
import { ContractSLA } from "../types";

const API_KEY = process.env.API_KEY || "";

export const analyzeContract = async (text: string, fileData?: { data: string, mimeType: string }): Promise<ContractSLA> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  const prompt = `You are a world-class automotive finance expert and consumer advocate. 
  Analyze this car lease or loan contract document. 
  
  CONTEXT:
  - User is looking for hidden fees, predatory clauses, and fairness.
  - Typical market APR for Tier 1 is 4-7%, Tier 2 is 8-12%.
  - Standard lease mileage is 10k-12k miles/year.
  
  TASK:
  1. Extract all core financial SLA parameters.
  2. Identify "Red Flags" like force-placed insurance, mandatory dealer add-ons (etching, nitrogen), or high doc fees.
  3. Provide a summary that explains if this is a "Good", "Fair", or "Poor" deal.
  
  DOCUMENT TEXT/CONTEXT: ${text}`;

  const parts: any[] = [{ text: prompt }];
  if (fileData) {
    parts.push({
      inlineData: {
        mimeType: fileData.mimeType,
        data: fileData.data
      }
    });
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: { parts },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          apr: { type: Type.NUMBER },
          termMonths: { type: Type.NUMBER },
          monthlyPayment: { type: Type.NUMBER },
          downPayment: { type: Type.NUMBER },
          residualValue: { type: Type.NUMBER },
          mileageAllowance: { type: Type.NUMBER },
          overageChargePerMile: { type: Type.NUMBER },
          earlyTerminationFee: { type: Type.STRING },
          purchaseOptionPrice: { type: Type.NUMBER },
          maintenanceIncluded: { type: Type.BOOLEAN },
          warrantyDetails: { type: Type.STRING },
          penalties: { type: Type.ARRAY, items: { type: Type.STRING } },
          fairnessScore: { type: Type.NUMBER },
          redFlags: { type: Type.ARRAY, items: { type: Type.STRING } },
          summary: { type: Type.STRING }
        },
        required: ["apr", "termMonths", "monthlyPayment", "fairnessScore", "summary"]
      }
    }
  });

  return JSON.parse(response.text || "{}");
};

export const getNegotiationAdvice = async (sla: ContractSLA, vinInfo: any, userQuery: string) => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  const prompt = `You are an expert car purchase negotiator. 
  Context:
  Vehicle: ${vinInfo?.year} ${vinInfo?.make} ${vinInfo?.model}
  Contract Terms: APR ${sla.apr}%, Term ${sla.termMonths}mo, Payment $${sla.monthlyPayment}, Mileage ${sla.mileageAllowance}/yr.
  User Question: ${userQuery}
  
  Provide helpful, assertive advice on how to negotiate these terms. Suggest specific questions for the dealer and provide an email template if appropriate. Use markdown for formatting.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt
  });

  return response.text;
};
