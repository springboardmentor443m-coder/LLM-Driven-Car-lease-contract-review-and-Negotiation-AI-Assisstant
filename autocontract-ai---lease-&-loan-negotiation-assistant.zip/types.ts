
export interface ContractSLA {
  apr: number;
  termMonths: number;
  monthlyPayment: number;
  downPayment: number;
  residualValue: number;
  mileageAllowance: number;
  overageChargePerMile: number;
  earlyTerminationFee: string;
  purchaseOptionPrice: number;
  maintenanceIncluded: boolean;
  warrantyDetails: string;
  penalties: string[];
  fairnessScore: number;
  redFlags: string[];
  summary: string;
}

export interface VINInfo {
  vin: string;
  make: string;
  model: string;
  year: string;
  trim?: string;
  bodyClass?: string;
  driveType?: string;
  engineCylinders?: string;
  fuelType?: string;
  manufacturer?: string;
  plantCountry?: string;
}

export interface SavedOffer {
  id: string;
  timestamp: number;
  sla: ContractSLA;
  vinInfo: VINInfo | null;
}

export interface MarketAnalysis {
  fairPriceRange: { min: number; max: number };
  marketAverage: number;
  analysisSource: string;
}

export interface NegotiationStep {
  id: string;
  question: string;
  advice: string;
  emailTemplate?: string;
}
