
import { VINInfo } from '../types';

export const decodeVIN = async (vin: string): Promise<VINInfo | null> => {
  try {
    const response = await fetch(`https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/${vin}?format=json`);
    const data = await response.json();
    
    if (data.Results && data.Results[0]) {
      const res = data.Results[0];
      return {
        vin: vin,
        make: res.Make,
        model: res.Model,
        year: res.ModelYear,
        trim: res.Trim,
        bodyClass: res.BodyClass,
        driveType: res.DriveType,
        engineCylinders: res.EngineCylinders,
        fuelType: res.FuelTypePrimary,
        manufacturer: res.Manufacturer,
        plantCountry: res.PlantCountry
      };
    }
    return null;
  } catch (error) {
    console.error("VIN decoding failed:", error);
    return null;
  }
};
