
import React, { useState, useRef, useEffect } from 'react';
import { getNegotiationAdviceStream } from '../services/aiEngine';
import { ContractSLA, VINInfo } from '../types';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
}

interface ChatbotProps {
  sla: ContractSLA | null;
  vinInfo: VINInfo | null;
}

const TACTICS = [
  { label: "Counter-Offer Script", text: "Give me a exact script to counter the current monthly payment. I want it $50 lower." },
  { label: "Kill Junk Fees", text: "Look at my red flags. Which ones are 100% negotiable and how do I ask to remove them?" },
  { label: "Check APR Fairness", text: "Based on current market rates, is my APR fair? How do I ask for a buy-rate instead of a marked-up rate?" },
  { label: "Lease Exit Plan", text: "I might want to trade this in early. What should I ask about 'early termination' and 'equity'?" },
  { label: "Professional Email", text: "Write a firm but professional email to the sales manager asking for a line-by-line breakdown of the 'Dealer Installed Options'." }
];

const Chatbot: React.FC<ChatbotProps> = ({ sla, vinInfo }) => {
  const [messages, setMessages] = useState<Message[]>([
    { 
      role: 'assistant', 
      content: "Ready for battle. I've reviewed your contract. We've got work to do on those fees. What's our first move?" 
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom as text streams in
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async (text?: string) => {
    const query = text || input.trim();
    if (!query || isProcessing || !sla) return;

    setInput('');
    setIsProcessing(true);
    
    // 1. Add User Message
    const userMessage: Message = { role: 'user', content: query };
    setMessages(prev => [...prev, userMessage]);

    // 2. Prepare Assistant Message Placeholder
    const assistantPlaceholder: Message = { role: 'assistant', content: '', isStreaming: true };
    setMessages(prev => [...prev, assistantPlaceholder]);

    try {
      let accumulatedResponse = "";
      const stream = getNegotiationAdviceStream(sla, vinInfo, query);

      for await (const chunk of stream) {
        accumulatedResponse += chunk;
        setMessages(prev => {
          const newMessages = [...prev];
          const lastIndex = newMessages.length - 1;
          newMessages[lastIndex] = { 
            ...newMessages[lastIndex], 
            content: accumulatedResponse 
          };
          return newMessages;
        });
      }
      
      // Finalize streaming state
      setMessages(prev => {
        const newMessages = [...prev];
        const lastIndex = newMessages.length - 1;
        newMessages[lastIndex].isStreaming = false;
        return newMessages;
      });

    } catch (error) {
      console.error("Chat Error:", error);
      setMessages(prev => [
        ...prev.slice(0, -1),
        { role: 'assistant', content: "🚨 Connection interrupted. The AI Engine is busy or your key might be invalid. Try again in a second." }
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="flex flex-col h-[700px] bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-800 ring-1 ring-white/10 animate-in zoom-in-95 duration-500">
      {/* Header */}
      <div className="px-6 py-5 bg-gradient-to-r from-slate-900 to-slate-800 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-blue-500/20">
              <i className="fas fa-shield-halved text-xl"></i>
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-slate-900 rounded-full"></div>
          </div>
          <div>
            <h3 className="text-white font-black tracking-tight">Pro-Negotiator v2.0</h3>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">Live Engine</span>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">•</span>
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Consumer Advocate</span>
            </div>
          </div>
        </div>
        <div className="hidden md:flex items-center space-x-2 bg-white/5 px-3 py-1.5 rounded-full border border-white/10">
          <i className="fas fa-bolt text-amber-400 text-xs"></i>
          <span className="text-[10px] font-black text-white uppercase tracking-tighter">Fast Mode Active</span>
        </div>
      </div>

      {/* Messages */}
      <div 
        ref={scrollRef} 
        className="flex-1 overflow-y-auto p-6 space-y-6 scrollbar-thin scrollbar-thumb-slate-700"
      >
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex items-start max-w-[85%] space-x-3 ${m.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center text-xs shadow-sm mt-1 ${
                m.role === 'user' ? 'bg-slate-700 text-slate-300' : 'bg-blue-600 text-white'
              }`}>
                <i className={`fas ${m.role === 'user' ? 'fa-user' : 'fa-robot'}`}></i>
              </div>
              <div className={`p-4 rounded-3xl text-sm leading-relaxed whitespace-pre-wrap ${
                m.role === 'user' 
                  ? 'bg-blue-600 text-white rounded-tr-none shadow-lg shadow-blue-900/20 font-medium' 
                  : 'bg-slate-800 text-slate-200 border border-white/5 rounded-tl-none prose prose-invert max-w-none'
              }`}>
                {m.content}
                {m.isStreaming && <span className="inline-block w-1.5 h-4 ml-1 bg-blue-400 animate-pulse align-middle"></span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Input Zone */}
      <div className="p-6 bg-slate-800/50 border-t border-white/5">
        {/* Tactics Playbook */}
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2 px-1">
            <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">Tactical Playbook</span>
            {!sla && <span className="text-[10px] font-bold text-rose-400 flex items-center animate-pulse"><i className="fas fa-lock mr-1"></i> Upload Contract First</span>}
          </div>
          <div className="flex overflow-x-auto pb-2 gap-2 no-scrollbar">
            {TACTICS.map((t, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(t.text)}
                disabled={isProcessing || !sla}
                className="whitespace-nowrap px-4 py-2 rounded-2xl border border-white/10 bg-slate-900 text-xs font-bold text-slate-400 hover:border-blue-500/50 hover:text-white hover:bg-slate-800 transition-all active:scale-95 disabled:opacity-30 disabled:grayscale"
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        <div className="relative group">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={isProcessing || !sla}
            placeholder={sla ? "Ask your negotiator anything..." : "Awaiting contract analysis..."}
            className="w-full bg-slate-900/50 border border-white/10 text-white rounded-[2rem] pl-6 pr-14 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/30 transition-all placeholder:text-slate-600 disabled:opacity-50"
          />
          <button 
            onClick={() => handleSend()}
            disabled={isProcessing || !input.trim() || !sla}
            className="absolute right-2 top-2 h-10 w-10 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-500 transition-all active:scale-90 disabled:opacity-20 shadow-lg shadow-blue-500/20"
          >
            {isProcessing ? (
              <i className="fas fa-circle-notch fa-spin text-xs"></i>
            ) : (
              <i className="fas fa-arrow-up text-sm"></i>
            )}
          </button>
        </div>
        
        <p className="text-center mt-4 text-[9px] font-bold text-slate-600 uppercase tracking-[0.2em]">
          Powered by AutoContract Tactical Engine • Zero Commission
        </p>
      </div>
    </div>
  );
};

export default Chatbot;
