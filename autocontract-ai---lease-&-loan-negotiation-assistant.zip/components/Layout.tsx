
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="glass sticky top-0 z-50 border-b border-slate-200">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <i className="fas fa-car-side text-white text-xl"></i>
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-800">AutoContract <span className="text-blue-600">AI</span></h1>
          </div>
          <nav className="hidden md:flex space-x-6 text-sm font-medium">
            <button 
              onClick={() => onTabChange('analyze')}
              className={`${activeTab === 'analyze' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Analyze
            </button>
            <button 
              onClick={() => onTabChange('negotiate')}
              className={`${activeTab === 'negotiate' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Negotiate
            </button>
            <button 
              onClick={() => onTabChange('history')}
              className={`${activeTab === 'history' ? 'text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Recent Offers
            </button>
          </nav>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-4 py-8">
        {children}
      </main>

      <footer className="md:hidden glass fixed bottom-0 left-0 right-0 border-t border-slate-200 pb-safe">
        <div className="flex justify-around items-center h-16">
          <button 
            onClick={() => onTabChange('analyze')}
            className={`flex flex-col items-center space-y-1 ${activeTab === 'analyze' ? 'text-blue-600' : 'text-slate-400'}`}
          >
            <i className="fas fa-file-contract text-lg"></i>
            <span className="text-[10px] font-medium uppercase">Analyze</span>
          </button>
          <button 
            onClick={() => onTabChange('negotiate')}
            className={`flex flex-col items-center space-y-1 ${activeTab === 'negotiate' ? 'text-blue-600' : 'text-slate-400'}`}
          >
            <i className="fas fa-comments text-lg"></i>
            <span className="text-[10px] font-medium uppercase">Negotiate</span>
          </button>
          <button 
            onClick={() => onTabChange('history')}
            className={`flex flex-col items-center space-y-1 ${activeTab === 'history' ? 'text-blue-600' : 'text-slate-400'}`}
          >
            <i className="fas fa-history text-lg"></i>
            <span className="text-[10px] font-medium uppercase">History</span>
          </button>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
