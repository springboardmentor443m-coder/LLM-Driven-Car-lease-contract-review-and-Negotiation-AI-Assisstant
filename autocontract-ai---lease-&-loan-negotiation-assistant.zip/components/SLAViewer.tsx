
import React from 'react';
import { ContractSLA, VINInfo } from '../types';

interface SLAViewerProps {
  sla: ContractSLA;
  vinInfo: VINInfo | null;
}

const SLAViewer: React.FC<SLAViewerProps> = ({ sla, vinInfo }) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-600';
    if (score >= 60) return 'text-amber-600';
    return 'text-rose-600';
  };

  const getScoreBg = (score: number) => {
    if (score >= 80) return 'bg-emerald-50 border-emerald-200';
    if (score >= 60) return 'bg-amber-50 border-amber-200';
    return 'bg-rose-50 border-rose-200';
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Overview Header */}
      <div className={`p-6 rounded-3xl border shadow-sm ${getScoreBg(sla.fairnessScore)} flex flex-col md:flex-row md:items-center justify-between gap-6`}>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
             <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${sla.fairnessScore >= 60 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                {sla.fairnessScore >= 80 ? 'Great Deal' : sla.fairnessScore >= 60 ? 'Fair Deal' : 'Poor Deal'}
             </span>
          </div>
          <h2 className="text-2xl font-black text-slate-800 tracking-tight">Contract Analysis</h2>
          {vinInfo && (
            <p className="text-slate-600 font-semibold flex items-center">
              <i className="fas fa-car mr-2 opacity-50"></i>
              {vinInfo.year} {vinInfo.make} {vinInfo.model}
            </p>
          )}
          <p className="text-sm text-slate-600 max-w-xl leading-relaxed">{sla.summary}</p>
        </div>
        <div className="flex flex-col items-center justify-center bg-white/50 backdrop-blur p-4 rounded-2xl border border-white/50 min-w-[140px]">
          <div className={`text-5xl font-black ${getScoreColor(sla.fairnessScore)}`}>{sla.fairnessScore}</div>
          <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-1">Fairness Score</div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Core Financials */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center">
            <i className="fas fa-hand-holding-dollar mr-2 text-blue-500"></i> Financials
          </h3>
          <div className="space-y-5">
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">Monthly Payment</span>
              <span className="text-xl font-bold text-slate-900">${sla.monthlyPayment}</span>
            </div>
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">APR / Interest</span>
              <div className="text-right">
                <span className="text-xl font-bold text-slate-900">{sla.apr}%</span>
                <p className="text-[10px] text-slate-400 font-medium">Market Avg: 7.2%</p>
              </div>
            </div>
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">Down Payment</span>
              <span className="text-xl font-bold text-slate-900">${sla.downPayment}</span>
            </div>
            <div className="flex justify-between items-end">
              <span className="text-slate-500 text-sm">Total Term</span>
              <span className="text-xl font-bold text-slate-900">{sla.termMonths} Months</span>
            </div>
          </div>
        </div>

        {/* Market Value/Usage */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center">
            <i className="fas fa-chart-line mr-2 text-indigo-500"></i> Market Value
          </h3>
          <div className="space-y-5">
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">Mileage Limit</span>
              <span className="text-xl font-bold text-slate-900">{sla.mileageAllowance?.toLocaleString()} mi/yr</span>
            </div>
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">Residual Value</span>
              <span className="text-xl font-bold text-slate-900">${sla.residualValue?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-end border-b border-slate-50 pb-3">
              <span className="text-slate-500 text-sm">Purchase Option</span>
              <span className="text-xl font-bold text-slate-900">${sla.purchaseOptionPrice?.toLocaleString()}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 text-sm">Maintenance</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${sla.maintenanceIncluded ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                {sla.maintenanceIncluded ? 'Included' : 'Paid Out-of-Pocket'}
              </span>
            </div>
          </div>
        </div>

        {/* Protection & Clauses */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 col-span-1 md:col-span-2 lg:col-span-1 hover:shadow-md transition-shadow">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-6 flex items-center">
            <i className="fas fa-shield-halved mr-2 text-amber-500"></i> Legal & Protection
          </h3>
          <div className="space-y-6">
            <div>
              <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Early Exit Strategy</span>
              <p className="text-sm text-slate-700 leading-snug italic">"{sla.earlyTerminationFee}"</p>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Overage Penalty</span>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold text-rose-600">${sla.overageChargePerMile}</span>
                <span className="text-xs text-slate-500">per mile over limit</span>
              </div>
            </div>
            <div>
               <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Warranty Info</span>
               <p className="text-sm text-slate-700 leading-snug">{sla.warrantyDetails}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Red Flags Section */}
      {sla.redFlags && sla.redFlags.length > 0 && (
        <div className="bg-rose-50 p-6 rounded-3xl border border-rose-100 shadow-sm animate-in slide-in-from-top-2 duration-1000">
          <h3 className="text-rose-700 font-black mb-4 flex items-center uppercase text-sm tracking-widest">
            <i className="fas fa-triangle-exclamation mr-3 text-lg"></i> Negotiable Red Flags
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {sla.redFlags.map((flag, idx) => (
              <div key={idx} className="bg-white/80 backdrop-blur-sm p-3 rounded-xl border border-rose-200/50 flex items-start space-x-3">
                <div className="w-5 h-5 rounded-full bg-rose-500 text-white flex items-center justify-center text-[10px] shrink-0 mt-0.5">!</div>
                <span className="text-sm text-slate-800 font-medium">{flag}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default SLAViewer;
