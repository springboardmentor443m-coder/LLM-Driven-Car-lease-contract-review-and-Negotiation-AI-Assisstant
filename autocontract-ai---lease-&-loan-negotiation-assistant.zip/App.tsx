
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import SLAViewer from './components/SLAViewer';
import Chatbot from './components/Chatbot';
import { analyzeContract } from './services/aiEngine';
import { decodeVIN } from './services/nhtsaService';
import { ContractSLA, VINInfo, SavedOffer } from './types';

const SAMPLE_CONTRACT: ContractSLA = {
  apr: 8.9,
  termMonths: 48,
  monthlyPayment: 612.45,
  downPayment: 2500,
  residualValue: 21800,
  mileageAllowance: 10000,
  overageChargePerMile: 0.30,
  earlyTerminationFee: "Lump sum penalty of $4,500 if terminated within first 24 months.",
  purchaseOptionPrice: 22150,
  maintenanceIncluded: false,
  warrantyDetails: "Basic bumper-to-bumper for 3 years / 36,000 miles. Power train for 5 years.",
  penalties: ["$50 late fee", "Repossession fee of $750"],
  fairnessScore: 54,
  redFlags: [
    "APR is 2.5% above national average for similar credit profiles.",
    "Early termination penalty is unusually high and rigid.",
    "Hidden 'documentation fee' of $899 is twice the state average.",
    "Gap insurance is mandatory but overpriced at $900."
  ],
  summary: "This is a below-average offer. The combination of high interest and excessive dealer fees puts your total cost of ownership significantly above market rates. High leverage for negotiation on the doc fee and APR."
};

const SAMPLE_VIN: VINInfo = {
  vin: "5NPDH4AE9EH123456",
  make: "HYUNDAI",
  model: "ELANTRA",
  year: "2024",
  trim: "Limited",
  manufacturer: "Hyundai Motor Manufacturing Alabama",
  plantCountry: "USA"
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('analyze');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [contractData, setContractData] = useState<ContractSLA | null>(null);
  const [vinInfo, setVinInfo] = useState<VINInfo | null>(null);
  const [vinInput, setVinInput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [portfolio, setPortfolio] = useState<SavedOffer[]>([]);

  // Load portfolio from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('autocontract_portfolio');
    if (saved) {
      try {
        setPortfolio(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse portfolio", e);
      }
    }
  }, []);

  // Save portfolio to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('autocontract_portfolio', JSON.stringify(portfolio));
  }, [portfolio]);

  const readFileAsDataURL = (file: File): Promise<{data: string, mimeType: string}> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        const [header, data] = result.split(',');
        const mimeType = header.match(/:(.*?);/)?.[1] || file.type;
        resolve({ data, mimeType });
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzing(true);
    setError(null);
    setContractData(null);
    
    try {
      const { data, mimeType } = await readFileAsDataURL(file);
      const result = await analyzeContract("Analyze this car contract document for financial terms.", { data, mimeType });
      setContractData(result);
    } catch (err) {
      console.error("Analysis Error:", err);
      setError("We couldn't read this file correctly. Please ensure it's a clear photo of your contract front page or a PDF.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleVINLookup = async () => {
    const cleanVin = vinInput.trim();
    if (!cleanVin || cleanVin.length < 11) {
      setError("Please enter a valid 17-character VIN.");
      return;
    }
    setIsAnalyzing(true);
    try {
      const result = await decodeVIN(cleanVin);
      if (result && result.make) {
        setVinInfo(result);
        setError(null);
      } else {
        setError("Vehicle not found. Double check the VIN digits.");
      }
    } catch (err) {
      setError("Network error fetching vehicle data.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const saveToPortfolio = () => {
    if (!contractData) return;
    const newOffer: SavedOffer = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      sla: contractData,
      vinInfo: vinInfo
    };
    setPortfolio(prev => [newOffer, ...prev]);
    alert("Offer saved to your portfolio!");
  };

  const loadFromPortfolio = (offer: SavedOffer) => {
    setContractData(offer.sla);
    setVinInfo(offer.vinInfo);
    setVinInput(offer.vinInfo?.vin || '');
    setActiveTab('analyze');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const deleteFromPortfolio = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm("Delete this saved offer?")) {
      setPortfolio(prev => prev.filter(o => o.id !== id));
    }
  };

  const loadSample = () => {
    setIsAnalyzing(true);
    setError(null);
    setContractData(null);
    setTimeout(() => {
      setContractData(SAMPLE_CONTRACT);
      setVinInfo(SAMPLE_VIN);
      setVinInput(SAMPLE_VIN.vin);
      setIsAnalyzing(false);
    }, 1500);
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {activeTab === 'analyze' && (
        <div className="space-y-8 pb-32">
          <div className="max-w-3xl mx-auto text-center space-y-4 mb-8">
            <h2 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tight leading-tight">
              Don't leave money <br className="hidden md:block"/> on the dealer's table.
            </h2>
            <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
              AutoContract AI uses advanced vision models to spot red flags in your car lease or loan in seconds.
            </p>
            <div className="pt-2 flex items-center justify-center space-x-4">
              <button 
                onClick={loadSample}
                className="inline-flex items-center space-x-2 text-blue-600 font-bold hover:text-blue-700 transition-colors bg-blue-50 px-4 py-2 rounded-full text-sm"
              >
                <i className="fas fa-play-circle"></i>
                <span>See a Sample Report</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            <div className="lg:col-span-4 space-y-6">
              {/* Step 1: VIN Lookup */}
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 ring-1 ring-slate-200/50">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-xs shadow-lg shadow-blue-200">1</div>
                  <h3 className="font-bold text-slate-800 tracking-tight">Identify Vehicle</h3>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-slate-400 block mb-2">Enter VIN #</label>
                    <div className="flex space-x-2">
                      <input 
                        type="text" 
                        value={vinInput}
                        onChange={(e) => setVinInput(e.target.value.toUpperCase())}
                        placeholder="17-Digit Code"
                        className="flex-1 border border-slate-200 rounded-xl px-4 py-3 text-sm uppercase font-mono tracking-wider focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                      />
                      <button 
                        onClick={handleVINLookup}
                        className="bg-slate-900 text-white px-5 py-3 rounded-xl text-sm font-black hover:bg-slate-800 transition-all active:scale-95"
                      >
                        <i className="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                  {vinInfo && (
                    <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl animate-in fade-in zoom-in-95 duration-500">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-[10px] font-black text-blue-600 uppercase mb-1 tracking-tighter">Verified Vehicle</p>
                          <p className="text-sm font-bold text-blue-950">{vinInfo.year} {vinInfo.make} {vinInfo.model}</p>
                          <p className="text-[10px] text-blue-400 font-medium uppercase">{vinInfo.trim || 'Standard Trim'}</p>
                        </div>
                        <i className="fas fa-check-circle text-blue-500"></i>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Step 2: Upload Contract */}
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 ring-1 ring-slate-200/50">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white font-black text-xs shadow-lg shadow-blue-200">2</div>
                  <h3 className="font-bold text-slate-800 tracking-tight">Contract Scan</h3>
                </div>
                <div className="space-y-4">
                  <div className="relative">
                    <input 
                      type="file" 
                      onChange={handleFileUpload}
                      className="hidden" 
                      id="contract-upload"
                      accept="image/*,application/pdf"
                    />
                    <label 
                      htmlFor="contract-upload"
                      className="w-full flex flex-col items-center justify-center border-2 border-dashed border-slate-200 rounded-3xl py-10 px-4 cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all group"
                    >
                      <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 mb-4 group-hover:scale-110 transition-transform group-hover:bg-blue-100">
                        <i className="fas fa-file-invoice-dollar text-2xl"></i>
                      </div>
                      <span className="text-sm font-black text-slate-800">Select Document</span>
                      <span className="text-xs text-slate-400 mt-1 font-medium">Clear photo or PDF</span>
                    </label>
                  </div>
                  
                  {isAnalyzing && (
                    <div className="flex flex-col items-center py-4 space-y-3">
                      <div className="flex items-center space-x-2 text-blue-600">
                         <i className="fas fa-circle-notch fa-spin"></i>
                         <span className="text-sm font-black uppercase tracking-widest">AI Extraction Active</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-blue-600 h-full w-2/3 animate-[progress_2s_infinite]"></div>
                      </div>
                    </div>
                  )}

                  {error && (
                    <div className="p-4 bg-rose-50 border border-rose-100 text-rose-700 rounded-2xl text-xs font-medium flex items-start animate-shake">
                      <i className="fas fa-circle-exclamation mr-3 mt-0.5 text-sm"></i> 
                      <span>{error}</span>
                    </div>
                  )}
                </div>
              </div>

              {contractData && (
                <button 
                  onClick={saveToPortfolio}
                  className="w-full bg-emerald-600 text-white font-black py-4 rounded-3xl shadow-xl shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95 flex items-center justify-center space-x-3"
                >
                  <i className="fas fa-bookmark"></i>
                  <span>Save to Portfolio</span>
                </button>
              )}
            </div>

            <div className="lg:col-span-8">
              {contractData ? (
                <SLAViewer sla={contractData} vinInfo={vinInfo} />
              ) : (
                <div className="h-full min-h-[500px] bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2rem] flex flex-col items-center justify-center p-12 text-center space-y-6">
                  <div className="relative">
                    <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-slate-200 text-4xl shadow-sm border border-slate-100 rotate-3">
                      <i className="fas fa-file-lines"></i>
                    </div>
                    <div className="w-24 h-24 bg-white rounded-3xl flex items-center justify-center text-slate-300 text-4xl shadow-md border border-slate-100 absolute inset-0 -rotate-3 transition-transform hover:rotate-0">
                      <i className="fas fa-magnifying-glass-chart"></i>
                    </div>
                  </div>
                  <div className="max-w-xs space-y-2">
                    <h3 className="font-black text-slate-800 text-xl tracking-tight">Waiting for Intel</h3>
                    <p className="text-sm text-slate-500 font-medium">Once you upload your agreement, we'll break down every penny and clause for you.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'negotiate' && (
        <div className="max-w-4xl mx-auto pb-32">
          <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div className="space-y-1">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Tactical Support</h2>
              <p className="text-slate-500 font-medium">Use AI-driven insights to challenge dealer fees and interest rates.</p>
            </div>
            {contractData && (
              <div className="bg-white px-5 py-3 rounded-2xl border border-slate-200 flex items-center space-x-4 shadow-sm">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <div className="text-xs font-black text-slate-400 uppercase tracking-widest">Active Analysis</div>
                <div className="font-black text-slate-900 text-lg">${contractData.monthlyPayment}<span className="text-xs text-slate-400 font-medium">/mo</span></div>
              </div>
            )}
          </div>
          <Chatbot sla={contractData} vinInfo={vinInfo} />
        </div>
      )}

      {activeTab === 'history' && (
        <div className="max-w-5xl mx-auto space-y-8 pb-32">
           <div className="flex items-center justify-between">
             <div className="space-y-1">
               <h2 className="text-3xl font-black text-slate-900 tracking-tight">Your Portfolio</h2>
               <p className="text-slate-500 font-medium">Saved analysis and comparison history.</p>
             </div>
             <div className="bg-blue-50 px-4 py-2 rounded-2xl border border-blue-100 text-blue-600 font-black text-xs uppercase tracking-widest">
               {portfolio.length} SAVED OFFERS
             </div>
           </div>

           {portfolio.length > 0 ? (
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                {portfolio.map((offer) => (
                  <div 
                    key={offer.id}
                    onClick={() => loadFromPortfolio(offer)}
                    className="group bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:border-blue-200 transition-all cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={(e) => deleteFromPortfolio(offer.id, e)}
                        className="w-8 h-8 rounded-full bg-rose-50 text-rose-500 hover:bg-rose-500 hover:text-white transition-colors flex items-center justify-center shadow-sm"
                      >
                        <i className="fas fa-trash text-xs"></i>
                      </button>
                    </div>
                    
                    <div className="flex items-center space-x-4 mb-4">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg ${
                        offer.sla.fairnessScore >= 80 ? 'bg-emerald-50 text-emerald-600' : 
                        offer.sla.fairnessScore >= 60 ? 'bg-amber-50 text-amber-600' : 'bg-rose-50 text-rose-600'
                      }`}>
                        {offer.sla.fairnessScore}
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">
                          {new Date(offer.timestamp).toLocaleDateString()}
                        </p>
                        <h4 className="font-bold text-slate-800 leading-tight">
                          {offer.vinInfo?.year} {offer.vinInfo?.make} {offer.vinInfo?.model || 'Unknown Vehicle'}
                        </h4>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-6">
                      <div className="bg-slate-50 p-3 rounded-2xl">
                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter block mb-1">Monthly</span>
                         <span className="font-black text-slate-900">${offer.sla.monthlyPayment}</span>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-2xl">
                         <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter block mb-1">APR</span>
                         <span className="font-black text-slate-900">{offer.sla.apr}%</span>
                      </div>
                    </div>

                    <div className="mt-6 flex items-center text-blue-600 font-bold text-xs group-hover:translate-x-1 transition-transform">
                      <span>View Detailed Breakdown</span>
                      <i className="fas fa-arrow-right ml-2"></i>
                    </div>
                  </div>
                ))}
             </div>
           ) : (
             <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-24 text-center space-y-6">
                <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto ring-8 ring-slate-50/50">
                  <i className="fas fa-folder-open text-4xl text-slate-200"></i>
                </div>
                <div className="max-w-xs mx-auto">
                  <h3 className="text-xl font-black text-slate-800 tracking-tight">Portfolio Empty</h3>
                  <p className="text-slate-500 text-sm mt-2 font-medium">Upload and analyze a contract to save it here for comparison and tactical negotiation help.</p>
                </div>
                <button 
                  onClick={() => setActiveTab('analyze')}
                  className="bg-slate-900 text-white px-8 py-3 rounded-full text-sm font-black hover:bg-slate-800 transition-all active:scale-95"
                >
                  Start First Analysis
                </button>
             </div>
           )}
        </div>
      )}
    </Layout>
  );
};

export default App;
